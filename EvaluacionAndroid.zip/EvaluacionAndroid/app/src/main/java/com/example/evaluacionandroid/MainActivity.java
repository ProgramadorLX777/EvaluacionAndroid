package com.example.evaluacionandroid;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    // Declaración de variables:
    private EditText txtRut;
    private Button btnValidar;
    private Button btnCalculadora;
    private TextView resultadoValidacion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Instancias de variables:
        txtRut = (EditText) findViewById(R.id.txtRut);
        btnValidar = (Button) findViewById(R.id.btnValidarRut);
        btnCalculadora = (Button) findViewById(R.id.btnCalculadora);
        resultadoValidacion = (TextView) findViewById(R.id.txtValidacion);

        // Método para validar el Rut mediante el método onClickListener:
        btnValidar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarRut();
            }
        });

        // Método para ir al activity Calculadora IMC mediante el método onClickListener:
        btnCalculadora.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Calculadora.class);
                startActivity(intent);
            }
        });

        /* Este método nos ayudará a filtrar los caracteres que se ingresan en el campo de texto, validando de que tipo son,
        para así evaluar cuales se pueden usar, para luego recorrer en un for esos caracteres para validarlos.*/
        txtRut.setFilters(new InputFilter[] {
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                        for (int i = start; i < end; i++) {
                            if (!Character.isDigit(source.charAt(i)) && source.charAt(i) != '-') {
                                return "";
                            }
                        }
                        return null;
                    }
                }
        });
    }

    // Método para validar el Rut:
    public void validarRut() {
        String rutString = txtRut.getText().toString().trim();
        if (validaRut(rutString)) {
            resultadoValidacion.setText("[+] RUT válido");
            Toast.makeText(this, "El Rut es válido", Toast.LENGTH_SHORT).show();
        } else {
            resultadoValidacion.setText("[!] RUT inválido!!");
            Toast.makeText(this, "El Rut es inválido, por favor intente nuevamente!!", Toast.LENGTH_LONG).show();
        }
        // Limpiar los campos de texto
        txtRut.setText("");
    }

    /*Los métodos Pattern y Matcher se utilizan para validar el RUT.
    En este caso el Pattern nos ayudará a crear un patrón que el RUT debe seguir: números, un guión y un dígito verificador, mientras que el Matcher
    nos ayudará a comparar el RUT ingresado con el patrón.*/
    public static Boolean validaRut(String rut) {
        Pattern pattern = Pattern.compile("^[0-9]+-[0-9kK]{1}$");
        Matcher matcher = pattern.matcher(rut);
        if (!matcher.matches()) return false;
        String[] stringRut = rut.split("-");
        return stringRut[1].toLowerCase().equals(dv(stringRut[0]));
    }

    /*Este método nos ayudará a calcular el dígito verificador del RUT mediante una declaración de variables que mediante un algoritmo
    calculará el dígito verificador.*/
    public static String dv(String rut) {
        Integer M = 0, S = 1, T = Integer.parseInt(rut);
        for (; T != 0; T = (int) Math.floor(T /= 10))
            S = (S + T % 10 * (9 - M++ % 6)) % 11;
        return (S > 0) ? String.valueOf(S - 1) : "k";
    }

}