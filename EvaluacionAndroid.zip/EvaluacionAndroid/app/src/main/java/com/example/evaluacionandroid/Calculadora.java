package com.example.evaluacionandroid;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Calculadora extends AppCompatActivity {

    // Declaración de variables:
    private EditText txtPeso;
    private EditText txtAltura;
    private Button btnCalcularIMC;
    private Button btnVolverValidador;
    private TextView txtResultadoIMC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculadora_imc);

        // Instancias de variables:
        txtPeso = (EditText) findViewById(R.id.txtPeso);
        txtAltura = (EditText) findViewById(R.id.txtAltura);
        btnCalcularIMC = (Button) findViewById(R.id.btnCalcularIMC);
        btnVolverValidador = (Button) findViewById(R.id.btnVolver);
        txtResultadoIMC = (TextView) findViewById(R.id.txtResultadoIMC);

        // Método para calcular el IMC mediante el método onClickListener:
        btnCalcularIMC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularIMC();
            }
        });

        // Método para volver al activity anterior:
        btnVolverValidador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // Método para calcular el IMC:
    public void calcularIMC() {
        String pesoString = txtPeso.getText().toString().trim();
        String alturaString = txtAltura.getText().toString().trim();

        // Validar si los campos están vacíos
        if (TextUtils.isEmpty(pesoString) || TextUtils.isEmpty(alturaString)) {
            Toast.makeText(this, "[!] Por favor rellene los campos!!", Toast.LENGTH_SHORT).show();
            return;
        }

        float pesoFloat = Float.parseFloat(pesoString);
        float alturaFloat = Float.parseFloat(alturaString);

        // Verificamos si la altura está en metros o centímetros: (Si la altura es mayor que 3, estará en centímetros y la convertimos a metros)
        if (alturaFloat > 3) {
            alturaFloat = alturaFloat / 100;
        }

        float resultadoIMC = pesoFloat / (alturaFloat * alturaFloat);

        if (resultadoIMC < 18.5) {
            txtResultadoIMC.setText(String.valueOf("Su IMC es: " + resultadoIMC + "\n Estado: Bajo peso"));
            Toast.makeText(this, "[+] Su estado es Bajo peso", Toast.LENGTH_SHORT).show();
        } else if (resultadoIMC >= 18.5 && resultadoIMC <= 24.9) {
            txtResultadoIMC.setText(String.valueOf("Su IMC es: " + resultadoIMC + "\n Estado: Peso normal"));
            Toast.makeText(this, "[+] Su estado es Peso normal", Toast.LENGTH_SHORT).show();
        } else if (resultadoIMC >= 25 && resultadoIMC <= 29.9) {
            txtResultadoIMC.setText(String.valueOf("Su IMC es: " + resultadoIMC + "\n Estado: Sobrepeso"));
            Toast.makeText(this, "[-] Su estado es Sobrepeso", Toast.LENGTH_SHORT).show();
        } else if (resultadoIMC >= 30 && resultadoIMC <= 34.9) {
            txtResultadoIMC.setText(String.valueOf("Su IMC es: " + resultadoIMC + "\n Estado: Obesidad grado 1"));
            Toast.makeText(this, "[!] Su estado es Obesidad grado 1", Toast.LENGTH_SHORT).show();
        } else if (resultadoIMC >= 35 && resultadoIMC <= 39.9) {
            txtResultadoIMC.setText(String.valueOf("Su IMC es: " + resultadoIMC + "\n Estado: Obesidad grado 2"));
            Toast.makeText(this, "[!!] Su estado es Obesidad grado 2", Toast.LENGTH_SHORT).show();
        } else if (resultadoIMC >= 40) {
            txtResultadoIMC.setText(String.valueOf("Su IMC es: " + resultadoIMC + "\n Estado: Obesidad grado 3"));
            Toast.makeText(this, "[!!!] Su estado es Obesidad grado 3", Toast.LENGTH_SHORT).show();
        } else {
            txtResultadoIMC.setText(String.valueOf("[!] Error al calcular el IMC!! \n Vuelva a intentarlo nuevamente!!"));
            Toast.makeText(this, "[!] Error al calcular el IMC!!", Toast.LENGTH_LONG).show();
        }

        // Limpiar los campos de texto
        txtPeso.setText("");
        txtAltura.setText("");
    }
}


